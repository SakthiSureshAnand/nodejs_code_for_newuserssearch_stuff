app.controller("AplicationLevelCtrl", [ '$scope', '$rootScope', '$location', '$window', '$q', '$http', 'RestURL',
				    function( $scope, $rootScope, $location, $window, $q, $http, RestURL) {
  $location.path('/landing_page-en');
}]);